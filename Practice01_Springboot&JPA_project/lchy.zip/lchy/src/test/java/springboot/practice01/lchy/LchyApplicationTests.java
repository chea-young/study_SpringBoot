package springboot.practice01.lchy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LchyApplicationTests {

	@Test
	void contextLoads() {
	}

}
