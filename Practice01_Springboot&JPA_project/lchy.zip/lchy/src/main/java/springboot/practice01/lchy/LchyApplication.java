package springboot.practice01.lchy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LchyApplication {

	public static void main(String[] args) {
		SpringApplication.run(LchyApplication.class, args);
	}

}
